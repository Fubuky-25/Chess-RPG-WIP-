import greenfoot.*;
import java.util.List;

public class Bomba extends Actor
{
    private static final int RADIO_EXPLOSION = 130;
    private static final int DANIO = 80;
    private int tiempoExplotar = 15; // Retardo antes de la explosión
    private boolean exploto = false;

    public Bomba()
    {
        GreenfootImage img = new GreenfootImage(20, 20);
        img.setColor(Color.BLACK);
        img.fillOval(0, 0, 20, 20);
        img.setColor(Color.RED);
        img.drawOval(2, 2, 16, 16);
        setImage(img);
    }

    public void act()
    {
        if (!exploto)
        {
            tiempoExplotar--;
            if (tiempoExplotar <= 0)
            {
                explotar();
            }
        }
    }

    private void explotar()
    {
        exploto = true;
        // Efecto visual de onda expansiva
        GreenfootImage exp = new GreenfootImage(RADIO_EXPLOSION * 2, RADIO_EXPLOSION * 2);
        exp.setColor(new Color(255, 100, 0, 180));
        exp.fillOval(0, 0, RADIO_EXPLOSION * 2, RADIO_EXPLOSION * 2);
        setImage(exp);

        // Hacer daño a todos los enemigos dentro del radio
        List<SoldadoEnemigo> enemigos = getWorld().getObjects(SoldadoEnemigo.class);
        for (SoldadoEnemigo e : enemigos)
        {
            int dx = e.getX() - getX();
            int dy = e.getY() - getY();
            if (Math.sqrt(dx * dx + dy * dy) <= RADIO_EXPLOSION)
            {
                e.recibirDanio(DANIO);
            }
        }

        // Remover del mundo tras la explosión
        getWorld().removeObject(this);
    }
}