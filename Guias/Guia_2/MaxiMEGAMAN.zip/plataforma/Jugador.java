import greenfoot.*;

public class Jugador extends Actor
{
    private enum Estado
    {
        QUIETO,
        CAMINANDO_DERECHA,
        CAMINANDO_IZQUIERDA,
        SALTANDO,
        CAYENDO
    }

    private static final int ESCALA = 3;

    private static final int ANCHO_IMAGEN = 26 * ESCALA;   
    private static final int ALTO_IMAGEN = 30 * ESCALA;    
    private static final int ANCHO_CAJA = 14 * ESCALA;     
    private static final int CUADROS_POR_FRAME = 6;

    private static final double GRAVEDAD = 0.8;
    private static final double IMPULSO_SALTO = -14.0;      
    private static final double CAIDA_MAXIMA = 16.0;        
    private static final int VELOCIDAD_CAMINATA = 5;

    private static final int MAXIMO_BALAS = 3;

    private Estado estado = Estado.QUIETO;

    private double vy = 0;
    private double yReal;

    private boolean enSuelo = false;
    private boolean mirandoIzquierda = false;

    private boolean pidiendoDerecha = false;
    private boolean pidiendoIzquierda = false;

    private boolean teclaDisparoAntes = false;

    private int frameActual = 0;
    private int contadorAnimacion = 0;

    private GreenfootImage quietoDerecha;
    private GreenfootImage quietoIzquierda;
    private GreenfootImage saltoDerecha;
    private GreenfootImage saltoIzquierda;
    private GreenfootImage[] caminarDerecha;
    private GreenfootImage[] caminarIzquierda;

    public Jugador()
    {
        cargarImagenes();
    }

    protected void addedToWorld(World mundo)
    {
        yReal = getY();
    }

    private void cargarImagenes()
    {
        quietoIzquierda = prepararSprite("idle.png");
        quietoDerecha = espejo(quietoIzquierda);

        saltoIzquierda = prepararSprite("jump.png");
        saltoDerecha = espejo(saltoIzquierda);

        caminarIzquierda = new GreenfootImage[4];
        caminarIzquierda[0] = prepararSprite("walk1.png");
        caminarIzquierda[1] = prepararSprite("walk2.png");
        caminarIzquierda[2] = prepararSprite("walk3.png");
        caminarIzquierda[3] = prepararSprite("walk4.png");

        caminarDerecha = new GreenfootImage[caminarIzquierda.length];

        for (int i = 0; i < caminarIzquierda.length; i++)
        {
            caminarDerecha[i] = espejo(caminarIzquierda[i]);
        }

        setImage(quietoDerecha);
    }

    private GreenfootImage prepararSprite(String archivo)
    {
        GreenfootImage original = new GreenfootImage(archivo);

        int ancho = original.getWidth() * ESCALA;
        int alto = original.getHeight() * ESCALA;
        original.scale(ancho, alto);

        GreenfootImage lienzo = new GreenfootImage(ANCHO_IMAGEN, ALTO_IMAGEN);
        lienzo.drawImage(original, (ANCHO_IMAGEN - ancho) / 2, ALTO_IMAGEN - alto);

        return lienzo;
    }

    private GreenfootImage espejo(GreenfootImage imagen)
    {
        GreenfootImage copia = new GreenfootImage(imagen);
        copia.mirrorHorizontally();
        return copia;
    }

    public void act()
    {
        controlarMovimientoHorizontal();
        controlarSalto();
        aplicarGravedad();
        actualizarEstado();
        controlarDisparo();
        actualizarAnimacion();
    }

    private void controlarMovimientoHorizontal()
    {
        pidiendoDerecha = Greenfoot.isKeyDown("right");
        pidiendoIzquierda = Greenfoot.isKeyDown("left");

        if (pidiendoDerecha && !pidiendoIzquierda)
        {
            moverEnX(VELOCIDAD_CAMINATA);
            mirandoIzquierda = false;
        }
        else if (pidiendoIzquierda && !pidiendoDerecha)
        {
            moverEnX(-VELOCIDAD_CAMINATA);
            mirandoIzquierda = true;
        }
    }

    private void moverEnX(int desplazamiento)
    {
        int nuevaX = getX() + desplazamiento;

        int minimo = ANCHO_CAJA / 2;
        int maximo = getWorld().getWidth() - ANCHO_CAJA / 2;

        if (nuevaX < minimo)
        {
            nuevaX = minimo;
        }
        else if (nuevaX > maximo)
        {
            nuevaX = maximo;
        }

        setLocation(nuevaX, getY());
    }

    private void controlarSalto()
    {
        if (Greenfoot.isKeyDown("space") && enSuelo)
        {
            vy = IMPULSO_SALTO;
            enSuelo = false;
        }
    }

    private void aplicarGravedad()
    {
        vy += GRAVEDAD;

        if (vy > CAIDA_MAXIMA)
        {
            vy = CAIDA_MAXIMA;
        }

        double piesAntes = pies();
        double piesDespues = piesAntes + vy;

        enSuelo = false;

        if (vy >= 0)
        {
            Plataforma soporte = buscarSoporte(piesAntes, piesDespues);

            if (soporte != null)
            {
                piesDespues = superficieDe(soporte);
                vy = 0;
                enSuelo = true;
            }
        }

        ubicarPies(piesDespues);
    }

    private Plataforma buscarSoporte(double piesAntes, double piesDespues)
    {
        Plataforma elegida = null;
        double mejorSuperficie = 0;

        for (Plataforma plataforma : getWorld().getObjects(Plataforma.class))
        {
            if (!haySuperposicionHorizontal(plataforma))
            {
                continue;
            }

            double superficie = superficieDe(plataforma);

            boolean cruzaLaSuperficie =
                superficie >= piesAntes - 1 && superficie <= piesDespues;

            if (!cruzaLaSuperficie)
            {
                continue;
            }

            if (elegida == null || superficie < mejorSuperficie)
            {
                elegida = plataforma;
                mejorSuperficie = superficie;
            }
        }

        return elegida;
    }

    private boolean haySuperposicionHorizontal(Plataforma plataforma)
    {
        int izquierdaJugador = getX() - ANCHO_CAJA / 2;
        int derechaJugador = getX() + ANCHO_CAJA / 2;

        int mitadPlataforma = plataforma.getImage().getWidth() / 2;
        int izquierdaPlataforma = plataforma.getX() - mitadPlataforma;
        int derechaPlataforma = plataforma.getX() + mitadPlataforma;

        return derechaJugador > izquierdaPlataforma
            && izquierdaJugador < derechaPlataforma;
    }

    private double superficieDe(Plataforma plataforma)
    {
        return plataforma.getY() - plataforma.getImage().getHeight() / 2.0;
    }

    private double pies()
    {
        return yReal + ALTO_IMAGEN / 2.0;
    }

    private void ubicarPies(double nuevaAlturaDePies)
    {
        yReal = nuevaAlturaDePies - ALTO_IMAGEN / 2.0;
        setLocation(getX(), (int) Math.round(yReal));
    }

    private void actualizarEstado()
    {
        if (!enSuelo)
        {
            estado = vy < 0 ? Estado.SALTANDO : Estado.CAYENDO;
        }
        else if (pidiendoDerecha && !pidiendoIzquierda)
        {
            estado = Estado.CAMINANDO_DERECHA;
        }
        else if (pidiendoIzquierda && !pidiendoDerecha)
        {
            estado = Estado.CAMINANDO_IZQUIERDA;
        }
        else
        {
            estado = Estado.QUIETO;
        }
    }

    private void controlarDisparo()
    {
        boolean teclaAhora = Greenfoot.isKeyDown("z");

        if (teclaAhora && !teclaDisparoAntes && quedanBalasDisponibles())
        {
            disparar();
        }

        teclaDisparoAntes = teclaAhora;
    }

    private boolean quedanBalasDisponibles()
    {
        return getWorld().getObjects(Bala.class).size() < MAXIMO_BALAS;
    }

    private void disparar()
    {
        int direccion = mirandoIzquierda ? -1 : 1;

        int x = getX() + direccion * (ANCHO_CAJA / 2 + 4);
        int y = getY() + 5;

        getWorld().addObject(new Bala(direccion), x, y);
    }

    private void actualizarAnimacion()
    {
        if (estado == Estado.SALTANDO || estado == Estado.CAYENDO)
        {
            setImage(mirandoIzquierda ? saltoIzquierda : saltoDerecha);
        }
        else if (estado == Estado.CAMINANDO_DERECHA)
        {
            animarCaminata(false);
        }
        else if (estado == Estado.CAMINANDO_IZQUIERDA)
        {
            animarCaminata(true);
        }
        else
        {
            setImage(mirandoIzquierda ? quietoIzquierda : quietoDerecha);
            reiniciarCaminata();
        }
    }

    private void animarCaminata(boolean izquierda)
    {
        contadorAnimacion++;

        if (contadorAnimacion >= CUADROS_POR_FRAME)
        {
            frameActual = (frameActual + 1) % caminarDerecha.length;
            contadorAnimacion = 0;
        }

        setImage(izquierda
            ? caminarIzquierda[frameActual]
            : caminarDerecha[frameActual]);
    }

    private void reiniciarCaminata()
    {
        frameActual = 0;
        contadorAnimacion = 0;
    }
}